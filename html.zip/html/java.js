function função1() {
    alert('iniciar')
}
function função2(){
    alert('pausar')
}
function função3(){
    let nome = window.prompt('Qual o seu nome')
    window.alert(`Olá, ${nome}! É um prazer te conhecer.`)
}