let resp=window.document.getElementById('saida')
function ação1() {
    resp. innerHTML += "<p>clicou no primeiro botão"
}
function ação2(){
    resp. innerHTML += "<p>clicou no segundo botão"
}
function ação3(){
    resp. innerHTML += "<p>clicou no terceiro botão"
}

function ação4(){
    resp. innerHTML += "<p>clicou no quarto botão"
}