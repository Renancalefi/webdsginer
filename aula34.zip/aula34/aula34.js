document.getElementById('LoginForm').addEventListener('submit', function(event){
    event.preventDefault();
    var username = document.getElementById('username').value;
    var username = document.getElementById('password').value;
    if(username ==='admim' && password==='admim'){
        document.getElementById('message').textContent='Login efeituado com sucesso!';
        window.Location.href = 'index.html';
    }
    else{
        document.getElementById('message').textContent ='Credenciais inválidas!';
    }
})