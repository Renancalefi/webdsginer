// window.alert('Seja bem vindo(a) ao meu site')
// function calcular(){
//     let n1 = Number(window.prompt('Digite um número'))
//     let res = document.querySelector('section#res')
//     res.innerHTML = `<p> O dobro de ${n1} é ${n1*2} e a metade é ${n1/2} </p>`
// }
function somar(){
    let n1= Number(window.prompt('Digite um número'))
    let n2= Number(window.prompt('Digite outro número'))
    soma = n1+n2
    
    let res = document.querySelector('section#res')
    res.innerHTML =`<p>A soma entre ${n1} e ${n2} é igual a ${soma}</p>`
}